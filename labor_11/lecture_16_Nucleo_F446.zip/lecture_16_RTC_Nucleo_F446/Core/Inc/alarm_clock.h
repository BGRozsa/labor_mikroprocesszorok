#ifndef INC_ALARM_CLOCK_H_
#define INC_ALARM_CLOCK_H_
// State machine of the alarm clock
void AlarmClock_MainFunction(void);

#endif /* INC_ALARM_CLOCK_H_ */
